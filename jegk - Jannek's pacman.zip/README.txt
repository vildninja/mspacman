The controllr is called TestController, and it should not require any setup
 - unless I manage to finish this evolutionary stuff .. :(